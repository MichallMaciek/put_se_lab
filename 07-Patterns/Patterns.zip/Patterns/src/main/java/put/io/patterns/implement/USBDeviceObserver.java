package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver {
    private int lastUsbCount = -1;

    @Override
    public void update(SystemMonitor monitor) {
        int currentCount = monitor.getLastSystemState().getUsbDevices();

        if (lastUsbCount != -1 && currentCount != lastUsbCount) {
            System.out.println(String.format("> USB Device count changed! Previous: %d, Current: %d", lastUsbCount, currentCount));
        }

        lastUsbCount = currentCount;
    }
}