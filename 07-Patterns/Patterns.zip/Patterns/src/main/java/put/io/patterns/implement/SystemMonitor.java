package put.io.patterns.implement;

import oshi.SystemInfo;
import oshi.hardware.*;
import oshi.software.os.OperatingSystem;
import java.util.ArrayList;
import java.util.List;

public class SystemMonitor {

    private SystemInfo si;

    private HardwareAbstractionLayer hal;

    private OperatingSystem os;

    private SystemState lastSystemState = null;

    private CentralProcessor cpu;

    private long[] prevTicks;

    private List<SystemStateObserver> observers = new ArrayList<>();

    public SystemMonitor(){
        si = new SystemInfo();
        hal = si.getHardware();
        os = si.getOperatingSystem();
        cpu = hal.getProcessor();
        prevTicks = cpu.getSystemCpuLoadTicks();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void addSystemStateObserver(SystemStateObserver observer){
        observers.add(observer);
    }

    public void removeSystemStateObserver(SystemStateObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (SystemStateObserver observer : this.observers) {
            observer.update(this);
        }
    }

    public void probe() {
        // Get current state of the system resources
        double cpuLoad = cpu.getSystemCpuLoadBetweenTicks(prevTicks) * 100;
        prevTicks = cpu.getSystemCpuLoadTicks();
        double cpuTemp = hal.getSensors().getCpuTemperature();
        double memory = hal.getMemory().getAvailable() / 1000000;
        int usbDevices = hal.getUsbDevices(false).size();

        lastSystemState = new SystemState(cpuLoad, cpuTemp, memory, usbDevices);
        notifyObservers();
    }

    public SystemState getLastSystemState() {
        return lastSystemState;
    }
}
